const input = document.getElementById('foodInput');
const suggestBox = document.getElementById('suggestList');
const resultBox = document.getElementById('foodResult');
const foodImgPath = 'assets/food/';

// Levenshtein distance for typo/variant matching
function levenshtein(a, b) {
  a = a.toLowerCase(); b = b.toLowerCase();
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const v0 = Array(b.length + 1).fill(0);
  const v1 = Array(b.length + 1).fill(0);
  for (let i = 0; i <= b.length; i++) v0[i] = i;
  for (let i = 0; i < a.length; i++) {
    v1[0] = i + 1;
    for (let j = 0; j < b.length; j++) {
      const cost = a[i] === b[j] ? 0 : 1;
      v1[j + 1] = Math.min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost);
    }
    for (let j = 0; j <= b.length; j++) v0[j] = v1[j];
  }
  return v1[b.length];
}
function similarity(a, b) {
  const lv = levenshtein(a,b);
  return 1 - (lv / Math.max(a.length, b.length, 1));
}

function getSuggestions(term) {
  term = (term || '').trim().toLowerCase();
  if (!term) return [];
  const foodList = Object.entries(foodData);
  let scored = foodList.map(([k,v])=>{
    let n = v.name || k;
    let sim = Math.max(
      similarity(term, k),
      similarity(term, n.toLowerCase())
    );
    let starts = k.startsWith(term) || n.toLowerCase().startsWith(term) ? 2 : 0;
    let inc = k.includes(term) || n.toLowerCase().includes(term) ? 1 : 0;
    return {k, n, img:v.image, score:sim+starts+inc};
  });
  scored = scored.filter(x=>x.score>1.1 || x.score>=0.50).sort((a,b)=>b.score-a.score);
  return scored.slice(0,8);
}
function fillSuggestions() {
  const term = input.value;
  const suggestions = getSuggestions(term);
  suggestBox.innerHTML = "";
  if (suggestions.length) {
    suggestions.forEach(({k, n, img}) => {
      const div = document.createElement('div');
      div.className = 'suggestion-item';
      div.innerHTML = (img ? `<img src="${foodImgPath+img}" alt="${n}" loading="lazy" />` : '') +
                      `<span><b>${highlightMatch(n, term)}</b></span>`;
      div.onclick = () => {
        input.value = n;
        suggestBox.removeAttribute("open");
        showFoodInfo(k);
      };
      suggestBox.appendChild(div);
    });
    suggestBox.setAttribute("open", "");
  } else {
    suggestBox.removeAttribute("open");
  }
}
function highlightMatch(foodName, typed) {
  const idx = foodName.toLowerCase().indexOf(typed.toLowerCase());
  if (typed && idx >= 0)
    return foodName.substring(0,idx)+'<b>'+foodName.substring(idx,idx+typed.length)+'</b>'+foodName.substring(idx+typed.length);
  return foodName;
}

input.addEventListener('input', fillSuggestions);
input.addEventListener('focus', fillSuggestions);
input.addEventListener('blur', () => setTimeout(()=>suggestBox.removeAttribute("open"), 180));

input.addEventListener('keydown', function(e){
  const items = suggestBox.querySelectorAll('.suggestion-item');
  if (!items.length) return;
  let active = suggestBox.querySelector('.active');
  let idx = Array.from(items).indexOf(active);
  if (e.key==='ArrowDown') {
    idx = (idx+1)%items.length; items.forEach((it,i)=>it.classList.toggle('active',i===idx)); e.preventDefault();
  } else if (e.key==='ArrowUp') {
    idx = (idx-1+items.length)%items.length; items.forEach((it,i)=>it.classList.toggle('active',i===idx)); e.preventDefault();
  } else if (e.key==='Enter' && active) { active.click(); e.preventDefault();
  } else if (e.key==='Escape') { suggestBox.removeAttribute("open"); }
});
window.searchFood = function() {
  let inp = input.value.trim().toLowerCase();
  let key = Object.keys(foodData).find(k =>
    k.toLowerCase() === inp ||
    (foodData[k].name && foodData[k].name.toLowerCase() === inp)
  );
  if (!key) {
    const suggestions = getSuggestions(inp);
    if (suggestions.length) key = suggestions[0].k;
  }
  if (!key || !foodData[key]) {
    resultBox.innerHTML = "<span style='color:#ff4182'>Food not found.</span>";
    resultBox.style.display = "block";
    return;
  }
  showFoodInfo(key);
};
function showFoodInfo(k) {
  const d = foodData[k];
  resultBox.innerHTML =
    (d.image ? `<img class="food-image" src="${foodImgPath+d.image}" alt="${d.name||k}" loading="lazy">` : '') +
    `<strong style="font-size:1.14em;color:var(--accent1);">${d.name||k}</strong><br>
    <span>Calories: <b>${d.kcal}</b> kcal / 100g</span><br>
    <span>Protein: <b>${d.protein}</b>g | Carbs: <b>${d.carbs}</b>g | Fat: <b>${d.fat}</b>g</span>`;
  resultBox.style.display = "block";
}
