

const foodData = {
    // Breads & Grains
    "chapati": { "kcal": 85, "protein": 3, "carbs": 18, "fat": 0.5, "name": "चपाती", "image": "chapati.png" },
    "rice_white": { "kcal": 130, "protein": 2.7, "carbs": 28, "fat": 0.3, "name": "सफेद चावल (पका हुआ)", "image": "rice.png" },
    "paratha": { "kcal": 150, "protein": 4, "carbs": 25, "fat": 4, "name": "पराठा", "image": "paratha.png" },
    "naan": { "kcal": 315, "protein": 10, "carbs": 55, "fat": 6, "name": "नान", "image": "naan.png" },
    "jowar_bhakri": { "kcal": 90, "protein": 2.5, "carbs": 20, "fat": 0.6, "name": "ज्वार भाकरी", "image": "bhakri.png" },
    "bajra_roti": { "kcal": 110, "protein": 3.5, "carbs": 24, "fat": 1, "name": "बाजरा रोटी", "image": "bajra_roti.png" },
    "brown_rice": { "kcal": 111, "protein": 2.6, "carbs": 23, "fat": 0.9, "name": "ब्राउन राइस (पका हुआ)", "image": "brown_rice.png" },
    "puri": { "kcal": 101, "protein": 1.2, "carbs": 12, "fat": 5, "name": "पूरी", "image": "puri.png" },
    "idli": { "kcal": 39, "protein": 1, "carbs": 8, "fat": 0.2, "name": "इडली (१ पीस)", "image": "idli.png" },
    "dosa_plain": { "kcal": 165, "protein": 4, "carbs": 35, "fat": 1.5, "name": "डोसा (सादा)", "image": "dosa.png" },

    // Lentils (Dal)
    "toor_dal": { "kcal": 110, "protein": 7, "carbs": 20, "fat": 1, "name": "तूर दाल (पकी हुई)", "image": "toor_dal.png" },
    "moong_dal": { "kcal": 105, "protein": 7, "carbs": 19, "fat": 0.5, "name": "मूंग दाल (पकी हुई)", "image": "moong_dal.png" },
    "chana_dal": { "kcal": 164, "protein": 8, "carbs": 28, "fat": 1, "name": "चना दाल (पकी हुई)", "image": "chana_dal.png" },
    "rajma": { "kcal": 127, "protein": 8, "carbs": 23, "fat": 0.5, "name": "राजमा", "image": "rajma.png" },
    "chana_masala": { "kcal": 150, "protein": 6, "carbs": 22, "fat": 4, "name": "छोले मसाला", "image": "chana_masala.png" },

    // Vegetables (Sabji)
    "aloo_gobi": { "kcal": 98, "protein": 3, "carbs": 12, "fat": 4.5, "name": "आलू गोभी", "image": "aloo_gobi.png" },
    "bhindi_masala": { "kcal": 80, "protein": 2, "carbs": 8, "fat": 5, "name": "भिंडी मसाला", "image": "bhindi_masala.png" },
    "palak_paneer": { "kcal": 190, "protein": 10, "carbs": 8, "fat": 14, "name": "पालक पनीर", "image": "palak_paneer.png" },
    "baingan_bharta": { "kcal": 75, "protein": 2, "carbs": 10, "fat": 3, "name": "बैंगन का भरता", "image": "baingan_bharta.png" },
    "mixed_veg": { "kcal": 95, "protein": 3, "carbs": 10, "fat": 5, "name": "मिक्स वेज करी", "image": "mixed_veg.png" },

    // Non-Veg
    "chicken_curry": { "kcal": 240, "protein": 25, "carbs": 6, "fat": 13, "name": "चिकन करी", "image": "chicken_curry.png" },
    "egg_boiled": { "kcal": 77, "protein": 6, "carbs": 0.6, "fat": 5, "name": "उबला अंडा", "image": "boiled_egg.png" },
    "egg_omelette": { "kcal": 95, "protein": 7, "carbs": 1, "fat": 7, "name": "आमलेट", "image": "omelette.png" },
    "fish_fry": { "kcal": 280, "protein": 22, "carbs": 10, "fat": 16, "name": "मछली फ्राई", "image": "fish_fry.png" },

    // Dairy & Others
    "milk": { "kcal": 60, "protein": 3.2, "carbs": 4.8, "fat": 3.3, "name": "दूध (१०० मिली)", "image": "milk.png" },
    "curd": { "kcal": 60, "protein": 3.5, "carbs": 4, "fat": 3, "name": "दही", "image": "curd.png" },
    "paneer": { "kcal": 265, "protein": 18, "carbs": 1.2, "fat": 20, "name": "पनीर", "image": "paneer.png" },
    "ghee": { "kcal": 900, "protein": 0, "carbs": 0, "fat": 100, "name": "घी", "image": "ghee.png" },
    "butter": { "kcal": 717, "protein": 0.9, "carbs": 0.1, "fat": 81, "name": "मक्खन", "image": "butter.png" },
    "poha": { "kcal": 110, "protein": 2, "carbs": 24, "fat": 1, "name": "पोहा", "image": "poha.png" },
    "upma": { "kcal": 190, "protein": 5, "carbs": 30, "fat": 6, "name": "उपमा", "image": "upma.png" },

    // Fruits & Vegetables (Raw)
    "apple": { "kcal": 52, "protein": 0.3, "carbs": 14, "fat": 0.2, "name": "सेब", "image": "apple.png" },
    "banana": { "kcal": 89, "protein": 1.1, "carbs": 23, "fat": 0.3, "name": "केला", "image": "banana.png" },
    "mango": { "kcal": 60, "protein": 0.8, "carbs": 15, "fat": 0.4, "name": "आम", "image": "mango.png" },
    "orange": { "kcal": 47, "protein": 0.9, "carbs": 12, "fat": 0.1, "name": "संतरा", "image": "orange.png" },
    "onion": { "kcal": 40, "protein": 1.1, "carbs": 9, "fat": 0.1, "name": "प्याज", "image": "onion.png" },
    "tomato": { "kcal": 18, "protein": 0.9, "carbs": 3.9, "fat": 0.2, "name": "टमाटर", "image": "tomato.png" },
    "cucumber": { "kcal": 15, "protein": 0.7, "carbs": 3.6, "fat": 0.1, "name": "खीरा", "image": "cucumber.png" },
    "potato": { "kcal": 77, "protein": 2, "carbs": 17, "fat": 0.1, "name": "आलू", "image": "potato.png" },

    // Snacks
    "samosa": { "kcal": 262, "protein": 4, "carbs": 24, "fat": 17, "name": "समोसा", "image": "samosa.png" },
    "vada_pav": { "kcal": 290, "protein": 7, "carbs": 45, "fat": 10, "name": "वड़ा पाव", "image": "vada_pav.png" }
};
